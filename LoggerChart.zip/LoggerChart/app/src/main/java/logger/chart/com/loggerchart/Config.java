package logger.chart.com.loggerchart;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;

public class Config extends AppCompatActivity {

    private String getAddress = new String();
    private String getPort = new String();
    private int port;
    private boolean autoCheck = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_config);

        final EditText editTextAddress = (EditText)findViewById(R.id.addressTextGet);
        final EditText editTextPort = (EditText)findViewById(R.id.portTextGet);

        CheckBox checkBox = (CheckBox)findViewById(R.id.autoCheckBox);
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    editTextAddress.setEnabled(false);
                    editTextPort.setEnabled(false);
                    autoCheck = true;
                }else{
                    editTextAddress.setEnabled(true);
                    editTextPort.setEnabled(true);
                    autoCheck = false;
                }
            }
        });


        Button button =(Button)findViewById(R.id.btn_send);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent linkIntent = new Intent(Config.this, ChartActivity.class);
                if (!autoCheck){
                    getAddress = editTextAddress.getText().toString();
                    getPort = editTextPort.getText().toString();
                    port = Integer.parseInt(getPort);
                    linkIntent.putExtra("AddressName", getAddress);
                    linkIntent.putExtra("PortName", port);
                    linkIntent.putExtra("AutomaticallySet", autoCheck);
                    startActivity(linkIntent);
                }
                else {
                    linkIntent.putExtra("AutomaticallySet", autoCheck);
                    startActivity(linkIntent);
                }

            }
        });
    }
}
