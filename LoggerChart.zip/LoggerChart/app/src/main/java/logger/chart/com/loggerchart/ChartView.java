package logger.chart.com.loggerchart;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.ImageView;

public class ChartView extends ImageView {

    private Paint paint;
    private static final int DATA_COUNT = 1000000;
    private float [] data = new float[DATA_COUNT];
    private float xStep = 1.0f;
    private float axisStep = 50.0f;

    private float max;
    private float min;
    private float partialMax;
    private float partialMin;

    private String addressName;
    private int portName;
    private boolean checkAuto;

    UDP udp;
    public void setConfig (String address, int port, boolean check){
        addressName = address;
        portName = port;
        checkAuto = check;
        if (!checkAuto){
            udp = new UDP(portName,addressName);
            udp.startPacketing();
        }
        else {
        }
    }

    private void computeMax(){
        max = Float.MIN_VALUE;
        for (int i = 0; i < DATA_COUNT; i++){
            if (data[i] > max){
                max = data[i];
            }
        }
    }
    private void computePartialMax(int fromIndex , int endIndex){
        partialMax = Float.MIN_VALUE;
        for (int i = fromIndex; i < endIndex; i++){
            if (data[i] > partialMax){
                partialMax = data[i];
            }
        }
    }
    private void computeMin(){
        min = Float.MAX_VALUE;
        for (int i = 0; i < DATA_COUNT; i++){
            if (data[i] < min){
                min = data[i];
            }
        }
    }
    private void computePartialMin(int fromIndex , int endIndex){
        partialMin = Float.MAX_VALUE;
        for (int i = fromIndex; i < endIndex; i++){
            if (data[i] < partialMin){
                partialMin = data[i];
            }
        }
    }

//
//        partialMin <-> 800;
//        partialMax <-> 0;
//        mid <-> 400
//

    private float computePixel(float value){
        float height = getHeight();
        float partialHeight = partialMax - partialMin;
        return (partialMax - value) / partialHeight *height;

    }
    private float computeValue(float Pixel){
        float height = getHeight();
        float partialHeight = partialMax - partialMin;
        return partialMax - Pixel *partialHeight /height;

    }


/*    private void generateRandomData(){
        for (int i = 0; i < DATA_COUNT; i++){
//            data[i] = (float) (Math.random() * 1200);
//            data[i] = (float) (Math.sin(i/50.0))*100 + 100;
//            data[i] = i ;
            data[i] = (float) Math.tan(i / 4.0f);
        }
        computeMax();
        computeMin();
    }*/
    private void generateData2(){
        udp.removePacket();
        for (int i = getWidth(); i < DATA_COUNT; i++){
            data [i] = udp.getChannel04();
            udp.removePacket();
        }
    }
    private void generateData(){

        final Thread threadData = new Thread(new Runnable() {
            @Override
            public void run() {
                udp.removePacket();
                try {
                    for (int i = getWidth(); i < DATA_COUNT; i++){
                        data [i] = udp.getChannel04();
                        Thread.sleep(1);
                        udp.removePacket();
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

            }
        });
    }


    public ChartView (Context context){
        super(context);
        initialize();
    }
    public ChartView (Context context, AttributeSet attrs){
        super(context, attrs);
        initialize();
    }
    public ChartView (Context context, AttributeSet attrs, int defStyleAttr){
        super(context, attrs, defStyleAttr);
        initialize();
    }


    private void initialize() {
        udp.startPacketing();
        generateData();
        generateData2();
//        generateRandomData();

        paint = new Paint();
        paint.setColor(Color.WHITE);
        paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.STROKE);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(10);

        autoScroll();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float startPosition = offset/xStep;
        int startIndex = (int) startPosition;

        int width = getWidth();
        int possibleRenderCount = (int) (width / xStep);


        if (startIndex < 1){
            startIndex = 1;
        }


        if (startIndex < DATA_COUNT){
            int endIndex = startIndex + possibleRenderCount + 2;
            if (endIndex >= DATA_COUNT){
                endIndex = DATA_COUNT;
            }

            float verticalAxisStep;
            float halfHeight = getHeight() / 2.0f;
            float halfWidth = getWidth() / 2.0f;

            computePartialMax(startIndex, endIndex);
            computePartialMin(startIndex, endIndex);

            verticalAxisStep = getHeight()  / 20.0f;
            for (int i = startIndex; i < endIndex; i++){
                paint.setColor(Color.rgb(010,200,100));
                canvas.drawLine((i - 1 - startPosition) * xStep, computePixel(data[i - 1]), (i - startPosition) * xStep, computePixel(data[i]), paint);
            }
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setColor(Color.YELLOW);
            canvas.drawLine(0, halfHeight, getWidth(), halfHeight, paint);
            for (int i = startIndex; i < endIndex + 1; i++){
                canvas.drawLine((i - startPosition) * axisStep, halfHeight - 5, (i - startPosition) * axisStep, halfHeight + 5, paint);
                canvas.drawText("" + i, (i - startPosition) * axisStep, halfHeight + 15, paint);
            }
            paint.setTextAlign(Paint.Align.LEFT);
            canvas.drawLine(1, 0, 1, getHeight(), paint);
            for(int j = 0 ; j < 20 ; j++){
                canvas.drawLine(-4, verticalAxisStep * j, 6, verticalAxisStep * j, paint);
                canvas.drawText("" + String.format("%.2f", computeValue(verticalAxisStep * j)), 10, verticalAxisStep * j + 8, paint);

            }
        }
    }

    private float LastDownX;
    private float LastDownY;

    private float offset;

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()){
            case MotionEvent.ACTION_DOWN:
                LastDownX = event.getRawX();
                LastDownY = event.getRawY();
                break;
            case MotionEvent.ACTION_MOVE:
                float currentX = event.getRawX();
                offset += LastDownX - currentX;
                if (offset < 0){
                    offset = 0;
                }
                LastDownX = currentX;
                invalidate();
                break;
        }
        return true;
    }

    private void autoScroll(){
        final Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                while (true){
                    try {

                        Thread.sleep(10);
                        offset += xStep;
                        postInvalidate();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                }

            }
        });
        thread.start();
    }
}