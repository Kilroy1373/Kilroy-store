package logger.chart.com.loggerchart;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class ChartActivity extends AppCompatActivity {
    private String getAddressName;
    private int getPort;
    private boolean getCheck;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getAddressName = getIntent().getStringExtra("AddressName");
        getPort = getIntent().getIntExtra("PortName", 0);
        getCheck = getIntent().getBooleanExtra("AutomaticallySet", false);
        setContentView(R.layout.activity_chart);
        ChartView chartView = (ChartView) findViewById(R.id.chartView);
        chartView.setConfig("127.0.0.0", 61556, getCheck);

    }
}
