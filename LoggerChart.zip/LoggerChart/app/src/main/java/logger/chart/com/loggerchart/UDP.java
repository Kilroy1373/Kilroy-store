package logger.chart.com.loggerchart;

import android.util.Log;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.LinkedList;
import java.util.Queue;


public class UDP {
    private int port;
    private Queue<byte[]> byteQueue = new LinkedList<>();
    private byte[] receiveData = new byte[100];
    private byte[] receiveQueue = new byte[100];
    private byte temp;
    private static final String hostAddress = null;
    private InetAddress localAddress;
    private DatagramSocket datagramSocket;
    private DatagramPacket datagramPacket;

    private int channel01;
    private int channel02;
    private int channel03;
    private int channel04;
    private int channel05;
    private int channel06;
    private int channel07;
    private int channel08;
    private int channel09;
    private int channel10;
    private int channel11;
    private int channel12;
    private int channel13;
    private int channel14;
    private int channel15;
    private int channel16;



    public UDP(int port, String hostAddress){
        try{

            datagramSocket = new DatagramSocket(25000);
            localAddress = InetAddress.getByName("169.254.0.50");
            datagramPacket = new DatagramPacket(receiveData, receiveData.length, localAddress, port);
        }
        catch(Exception err){
            Log.d("Err",err.getMessage());
        }
    }

    void startPacketing(){
         Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                while (true){
                    try {
                        datagramSocket = new DatagramSocket(25000);
                        localAddress = InetAddress.getByName("169.254.0.50");
                        datagramPacket = new DatagramPacket(receiveData, receiveData.length, localAddress, port);
                        datagramSocket.receive(datagramPacket);
                        receiveData = datagramPacket.getData();
                        byteQueue.add(receiveData);
                    }
                    catch(Exception e){
                        Log.e("receive", e.getMessage());
                        e.printStackTrace();
                    }
                }

            }
        });
        thread.start();

    }

    public void removePacket (){
        receiveQueue = byteQueue.remove();
    }

    public int getChannel01 ()
    {
        channel01 = receiveQueue[9];
        channel01 *= 256;
        channel01 += receiveQueue[8];
        return channel01;
    }
    public int getChannel02 (){
        channel02 = receiveQueue[11];
        channel02 *= 256;
        channel02 += receiveQueue[10];
        return channel02;
    }
    public int getChannel03 (){
        channel03 = receiveQueue[13];
        channel03 *= 256;
        channel03 += receiveQueue[12];
        return channel03;
    }
    public int getChannel04 (){
        channel04 = receiveQueue[15];
        channel04 *= 256;
        channel04 += receiveQueue[14];
        return channel04;
    }
    public int getChannel05 (){
        channel05 = receiveQueue[17];
        channel05 *= 256;
        channel05 += receiveQueue[16];
        return channel05;
    }
    public int getChannel06 (){
        channel06 = receiveQueue[19];
        channel06 *= 256;
        channel06 += receiveQueue[18];
        return channel06;
    }
    public int getChannel07 (){
        channel07 = receiveQueue[21];
        channel07 *= 256;
        channel07 += receiveQueue[20];
        return channel07;
    }
    public int getChannel08 (){
        channel08 = receiveQueue[23];
        channel08 *= 256;
        channel08 += receiveQueue[22];
        return channel08;
    }
    public int getChannel09 (){
        channel09 = receiveQueue[25];
        channel09 *= 256;
        channel09 += receiveQueue[24];
        return channel09;
    }
    public int getChannel10 (){
        channel10 = receiveQueue[27];
        channel10 *= 256;
        channel10 += receiveQueue[26];
        return channel10;
    }
    public int getChannel11 (){
        channel11 = receiveQueue[29];
        channel11 *= 256;
        channel11 += receiveQueue[28];
        return channel11;
    }
    public int getChannel12 (){
        channel12 = receiveQueue[31];
        channel12 *= 256;
        channel12 += receiveQueue[30];
        return channel12;
    }
    public int getChannel13 (){
        channel13 = receiveQueue[33];
        channel13 *= 256;
        channel13 += receiveQueue[32];
        return channel13;
    }
    public int getChannel14 (){
        channel14 = receiveQueue[35];
        channel14 *= 256;
        channel14 += receiveQueue[34];
        return channel14;
    }
    public int getChannel15 (){
        channel15 = receiveQueue[37];
        channel15 *= 256;
        channel15 += receiveQueue[36];
        return channel15;
    }
    public int getChannel16 (){
        channel16 = receiveQueue[39];
        channel16 *= 256;
        channel16 += receiveQueue[38];
        return channel16;
    }


}
